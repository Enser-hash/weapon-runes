# Credits

Rune artwork: **"Runes for Runelords - revised concepts" by Jeff Carlisle (2007)**.
Used with the artist's permission. The sheet was sliced into individual
glyphs with `tools/slice_runes.py`.
