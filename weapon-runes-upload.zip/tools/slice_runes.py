#!/usr/bin/env python3
"""
slice_runes.py - potong sheet "Runes for Runelords" jadi PNG putih transparan
dan susun jadi resource pack Minecraft (font bitmap).

Pemakaian:
    python tools/slice_runes.py source/runes_original.webp .

Hasil (relatif ke folder repo yang diberikan sebagai argumen ke-2):
    resourcepack/pack.mcmeta
    resourcepack/assets/weapon/font/runes.json
    resourcepack/assets/weapon/textures/font/rune/000.png ... 100.png
    runes_index.json            (index -> karakter -> nama, buat dipakai di plugin)
    dist/runes.zip              (siap di-upload ke GitHub Releases)
    dist/runes.zip.sha1         (hash untuk resource-pack-sha1)
    dist/preview.png            (contoh semua rune, buat dicek mata)

Butuh: pip install pillow numpy scipy
"""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as ndi
from scipy.spatial import cKDTree

NAMESPACE = "weapon"          # folder assets/<namespace>/
FONT_NAME = "runes"           # -> weapon:runes
FIRST_CHAR = 0xE000           # private-use area
CANVAS = 64                   # ukuran tiap PNG (px)
PAD = 2                       # jarak glyph ke tepi canvas
PACK_FORMAT = 46              # ganti sesuai versi Minecraft kamu
FONT_HEIGHT = 16              # tinggi tampil glyph di game
FONT_ASCENT = 14

# (kategori, cy_min, cy_max, x_min, x_max, jumlah_glyph, ukuran_seragam)
# Pita-pita ini memilih glyph saja (judul & label teks sengaja dikeluarkan).
# Urutannya = urutan baca: kiri atas -> kanan, lalu baris berikutnya, sampai bawah.
BANDS = [
    ("positive", 60, 180, 0, 9999, 12, False),
    ("positive", 180, 310, 0, 9999, 12, False),
    ("virtue", 320, 433, 200, 9999, 9, False),
    ("neutral", 519, 630, 0, 9999, 12, False),
    ("neutral", 640, 760, 0, 9999, 12, False),
    ("negative", 810, 925, 0, 9999, 12, False),
    ("negative", 925, 1035, 0, 9999, 12, False),
    ("sin", 1050, 1165, 300, 9999, 7, False),
    ("numeric", 1256, 1380, 60, 1030, 13, True),  # seragam: titik "zero" tetap kecil
]

NAMES = {
    "virtue": ["kindness", "courage", "hospitality", "skill", "fidelity",
               "discipline", "truth", "honor", "self_reliance"],
    "sin": ["lust", "envy", "sloth", "greed", "gluttony", "vanity", "wrath"],
    "numeric": ["zero", "one", "two", "three", "four", "five", "six", "seven",
                "eight", "nine", "ten", "twenty", "thirty"],
}


def find_groups(lab, objs, gray_shape, band):
    """Ambil komponen dalam satu pita, gabungkan potongan milik glyph yang sama
    (titik, bagian terpisah) sampai jumlahnya sama dengan yang diharapkan."""
    _, cy0, cy1, x0, x1, expected, _ = band
    comps = []
    for i, sl in enumerate(objs):
        if sl is None:
            continue
        ys, xs = sl
        cy = (ys.start + ys.stop) / 2
        cx = (xs.start + xs.stop) / 2
        if not (cy0 <= cy < cy1 and x0 <= cx < x1):
            continue
        m = lab[sl] == (i + 1)
        if m.sum() < 15:
            continue
        pts = np.argwhere(m) + np.array([ys.start, xs.start])
        comps.append({"ids": [i + 1], "pts": pts})

    n = len(comps)
    if n < expected:
        raise SystemExit(f"[{band[0]}] cuma ketemu {n} komponen, harusnya minimal {expected}")

    # jarak minimum antar pasangan komponen (piksel ke piksel)
    trees = [cKDTree(c["pts"]) for c in comps]
    INF = 1e9
    dist = np.full((n, n), INF)
    for a in range(n):
        for b in range(a + 1, n):
            d, _ = trees[a].query(comps[b]["pts"], k=1)
            dist[a, b] = dist[b, a] = d.min()

    alive = list(range(n))
    while len(alive) > expected:
        best = (INF, None, None)
        for ia, a in enumerate(alive):
            for b in alive[ia + 1:]:
                if dist[a, b] < best[0]:
                    best = (dist[a, b], a, b)
        d, a, b = best
        if d > 45:
            raise SystemExit(f"[{band[0]}] gagal menggabungkan potongan (jarak {d:.0f}px)")
        comps[a]["ids"] += comps[b]["ids"]
        comps[a]["pts"] = np.vstack([comps[a]["pts"], comps[b]["pts"]])
        for x in alive:
            if x not in (a, b):
                dist[a, x] = dist[x, a] = min(dist[a, x], dist[b, x])
        alive.remove(b)

    groups = [comps[i] for i in alive]
    for g in groups:
        g["cx"] = (g["pts"][:, 1].min() + g["pts"][:, 1].max()) / 2
    groups.sort(key=lambda g: g["cx"])
    return groups


def main():
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    src = Path(sys.argv[1])
    root = Path(sys.argv[2])

    gray = np.array(Image.open(src).convert("L"), dtype=np.float32)
    ink = gray < 128
    lab, n = ndi.label(ink, structure=np.ones((3, 3)))
    objs = ndi.find_objects(lab)

    all_groups = []  # (kategori, uniform, group)
    for band in BANDS:
        for g in find_groups(lab, objs, gray.shape, band):
            all_groups.append((band[0], band[6], g))

    # pemilik tiap komponen (glyph ke berapa, -1 = teks/lainnya)
    owner = np.full(n + 1, -1, dtype=np.int32)
    for k, (_, _, g) in enumerate(all_groups):
        for cid in g["ids"]:
            owner[cid] = k

    # tepi anti-alias: ambil dari komponen terdekat (maks 2.5 px)
    dist, (iy, ix) = ndi.distance_transform_edt(lab == 0, return_indices=True)
    pix_owner = owner[lab]
    fringe = (lab == 0) & (gray < 250) & (dist <= 2.5)
    pix_owner[fringe] = owner[lab[iy[fringe], ix[fringe]]]

    # ukuran seragam untuk kategori tertentu (angka)
    uniform_scale = {}
    for cat in {c for c, u, _ in all_groups if u}:
        dims = []
        for c, u, g in all_groups:
            if c == cat:
                h = np.ptp(g["pts"][:, 0]) + 1
                w = np.ptp(g["pts"][:, 1]) + 1
                dims.append(max(h, w))
        uniform_scale[cat] = (CANVAS - 2 * PAD) / max(dims)

    out_tex = root / "resourcepack/assets" / NAMESPACE / "textures/font/rune"
    out_font = root / "resourcepack/assets" / NAMESPACE / "font"
    out_tex.mkdir(parents=True, exist_ok=True)
    out_font.mkdir(parents=True, exist_ok=True)
    (root / "dist").mkdir(exist_ok=True)
    for old in out_tex.glob("*.png"):
        old.unlink()

    counters = {}
    index = []
    providers = []
    for k, (cat, uni, g) in enumerate(all_groups):
        counters[cat] = counters.get(cat, 0)
        name = NAMES[cat][counters[cat]] if cat in NAMES else f"{cat}_{counters[cat]:02d}"
        counters[cat] += 1

        ys0, xs0 = g["pts"].min(axis=0)
        ys1, xs1 = g["pts"].max(axis=0) + 1
        sub = (pix_owner[ys0:ys1, xs0:xs1] == k)
        a = np.where(sub, np.clip((255 - gray[ys0:ys1, xs0:xs1]) / 255 * 1.15, 0, 1), 0)
        alpha = Image.fromarray((a * 255).astype(np.uint8), "L")
        w, h = alpha.size

        fit = (CANVAS - 2 * PAD) / max(w, h)
        scale = uniform_scale[cat] if uni else fit
        scale = min(scale, fit)
        nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
        alpha = alpha.resize((nw, nh), Image.LANCZOS)

        canvas = Image.new("L", (CANVAS, CANVAS), 0)
        canvas.paste(alpha, ((CANVAS - nw) // 2, (CANVAS - nh) // 2))
        rgba = Image.merge("RGBA", [Image.new("L", (CANVAS, CANVAS), 255)] * 3 + [canvas])
        fname = f"{k:03d}.png"
        rgba.save(out_tex / fname, optimize=True)

        ch = chr(FIRST_CHAR + k)
        providers.append({
            "type": "bitmap",
            "file": f"{NAMESPACE}:font/rune/{fname}",
            "ascent": FONT_ASCENT,
            "height": FONT_HEIGHT,
            "chars": [ch],
        })
        index.append({"index": k, "char": f"\\u{ord(ch):04X}", "category": cat,
                      "name": name, "file": fname})

    (out_font / f"{FONT_NAME}.json").write_text(
        json.dumps({"providers": providers}, indent=2), encoding="utf-8")
    (root / "resourcepack/pack.mcmeta").write_text(json.dumps(
        {"pack": {"pack_format": PACK_FORMAT, "description": "Weapon Runes"}}, indent=2),
        encoding="utf-8")
    (root / "runes_index.json").write_text(json.dumps(index, indent=2), encoding="utf-8")

    # zip (pack.mcmeta harus di paling luar) dengan timestamp tetap supaya SHA-1 stabil
    zpath = root / "dist/runes.zip"
    base = root / "resourcepack"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(p for p in base.rglob("*") if p.is_file()):
            zi = zipfile.ZipInfo(f.relative_to(base).as_posix(), (2026, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(zi, f.read_bytes())
    sha1 = hashlib.sha1(zpath.read_bytes()).hexdigest()
    (root / "dist/runes.zip.sha1").write_text(sha1 + "\n")

    # preview
    cols, cell = 13, 72
    rows = (len(all_groups) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * cell, rows * (cell + 12)), (28, 28, 34))
    d = ImageDraw.Draw(sheet)
    for k in range(len(all_groups)):
        im = Image.open(out_tex / f"{k:03d}.png")
        x, y = (k % cols) * cell, (k // cols) * (cell + 12)
        sheet.paste(im.resize((cell - 8, cell - 8), Image.LANCZOS), (x + 4, y + 2), im.resize((cell - 8, cell - 8), Image.LANCZOS))
        d.text((x + 4, y + cell - 4), f"{k}", fill=(150, 200, 255))
    sheet.save(root / "dist/preview.png")

    print(f"{len(all_groups)} rune dibuat")
    for cat in dict.fromkeys(c for c, _, _ in all_groups):
        print(f"  {cat}: {counters[cat]}")
    print("SHA-1:", sha1)


if __name__ == "__main__":
    main()
